#!/bin/bash
# Script d'application de tous les fichiers V2 corrigés
# Lancer depuis /workspaces/bilnov-app

set -e

echo "🚀 Application des corrections V2..."

# Copier les fichiers depuis ce dossier
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Dashboard
cp "$SCRIPT_DIR/dashboard.tsx" src/app/dashboard/page.tsx
echo "✅ dashboard"

# Project page
cp "$SCRIPT_DIR/project.tsx" "src/app/projects/[id]/page.tsx"
echo "✅ project page"

# Tour editor
mkdir -p "src/app/projects/[id]/tours/[tourId]"
cp "$SCRIPT_DIR/tour-editor.tsx" "src/app/projects/[id]/tours/[tourId]/page.tsx"
echo "✅ tour editor"

# API routes
mkdir -p "src/app/api/projects/[id]/tours"
cp "$SCRIPT_DIR/tours-route.ts" "src/app/api/projects/[id]/tours/route.ts"
echo "✅ tours API"

mkdir -p "src/app/api/projects/[id]/tours/[tourId]"
cp "$SCRIPT_DIR/tour-by-id-route.ts" "src/app/api/projects/[id]/tours/[tourId]/route.ts"
echo "✅ tour by id API"

mkdir -p "src/app/api/projects/[id]/tours/[tourId]/publish"
cp "$SCRIPT_DIR/publish-route.ts" "src/app/api/projects/[id]/tours/[tourId]/publish/route.ts"
echo "✅ publish API"

mkdir -p "src/app/api/projects/[id]/tours/[tourId]/scenes"
cp "$SCRIPT_DIR/scenes-route.ts" "src/app/api/projects/[id]/tours/[tourId]/scenes/route.ts"
echo "✅ scenes API"

echo ""
echo "✅ Tous les fichiers appliqués !"
echo "👉 Maintenant: git add . && git commit -m 'V2 final' && git push"
